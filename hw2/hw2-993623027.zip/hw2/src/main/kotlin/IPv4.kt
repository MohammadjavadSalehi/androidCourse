package org.example

class IPv4 {
    var parts = ShortArray(4)

    constructor(address: String) {
        val ipArray = address.split(".")
        if (ipArray.size != 4) {
            throw IllegalArgumentException("Invalid array size: expected 4 but received ${ipArray.size}")
        }
        for ((index, part) in ipArray.withIndex()) {
            val num = part.toShortOrNull()
            if (num == null || num !in 0..255) {
                throw IllegalArgumentException("Invalid address: $address")
            }
            parts[index] = num
        }
    }

    constructor(vararg va: Short) {
        if (va.size != 4) {
            throw IllegalArgumentException("Invalid array size: expected 4 but received ${va.size}")
        }
        for ((index, ip) in va.withIndex()) {
            if (ip !in 0..255) {
                throw IllegalArgumentException("Invalid address: $ip")
            }
            parts[index] = ip
        }
    }

    override fun toString(): String {
        return parts.joinToString(separator = ".")
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is IPv4) return false
        return parts.contentEquals(other.parts)
    }

    override fun hashCode(): Int {
        return parts.contentHashCode()
    }
}
