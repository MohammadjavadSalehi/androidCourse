import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

internal class IPv4Test {

    @Test
    fun `constructor throws exception for invalid string address - out of range`() {
        val invalidAddress = "256.255.255.255"
        assertThrows(Exception::class.java) {
            IPv4(invalidAddress)
        }.let {
            assertEquals("Invalid address: $invalidAddress", it.message)
        }
    }

    @Test
    fun `constructor throws exception for invalid string address - nonnumeric`() {
        val invalidAddress = "a.255.255.255"
        assertThrows(Exception::class.java) {
            IPv4(invalidAddress)
        }
    }

    @Test
    fun `constructor throws exception for invalid string address - missing segments`() {
        val invalidAddress = "255.255.255"
        assertThrows(Exception::class.java) {
            IPv4(invalidAddress)
        }.let {
            assertTrue(it.message!!.contains("Invalid array size: expected 4 but received 3"))
        }
    }

    @Test
    fun `constructor throws exception for invalid string address - extra segments`() {
        val invalidAddress = "255.255.255.255.255"
        assertThrows(Exception::class.java) {
            IPv4(invalidAddress)
        }.let {
            assertTrue(it.message!!.contains("Invalid array size: expected 4 but received 5"))
        }
    }

    @Test
    fun `constructor throws exception for invalid string address - negative value`() {
        val invalidAddress = "10.-20.255.255"
        assertThrows(Exception::class.java) {
            IPv4(invalidAddress)
        }.let {
            assertTrue(it.message!!.contains("Invalid address: $invalidAddress"))
        }
    }

    @Test
    fun `constructor throws exception for invalid array size`() {
        val invalidArray = shortArrayOf(1, 2, 3)
        assertThrows(Exception::class.java) {
            IPv4(*invalidArray)
        }.let {
            assertEquals("Invalid array size: expected 4 but received ${invalidArray.size}", it.message)
        }
    }

    @Test
    fun `constructor throws exception for invalid array element - out of range`() {
        val invalidArray = shortArrayOf(256, 0, 0, 0)
        assertThrows(Exception::class.java) {
            IPv4(*invalidArray)
        }.let {
            assertTrue(it.message!!.contains("Invalid value: ${invalidArray[0]}"))
        }
    }

    @Test
    fun `valid string address constructor creates correct IPv4 object`() {
        val address = "192.168.1.1"
        val ipv4 = IPv4(address)
        assertArrayEquals(shortArrayOf(192, 168, 1, 1), ipv4.parts)
    }

    @Test
    fun `valid string address constructor string method`() {
        val address = "192.168.1.1"
        val ipv4 = IPv4(address)
        val s = "$ipv4"
        assertEquals(s, address)
    }

    @Test
    fun `valid array constructor creates correct IPv4 object`() {
        val parts = shortArrayOf(10, 20, 30, 40)
        val ipv4 = IPv4(*parts)
        assertArrayEquals(parts, ipv4.parts)
    }

    @Test
    fun `valid equal method`() {
        val address = "192.168.1.1"
        val ip1 = IPv4(address)
        val ip2 = IPv4(address)
        assertTrue(ip1 == ip2)
    }
}
